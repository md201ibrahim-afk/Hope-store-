HOPE WEBSITE — STARTER PREVIEW

1) Extract this ZIP.
2) Open the extracted folder and tap index.html to preview the customer website.
3) Tap Admin Login at the top. Demo password: hope123
4) Add/edit/delete products in the admin preview.

IMPORTANT LIMITATION:
This starter preview stores product changes in the browser's local storage. It is NOT yet a live multi-user store: changes made in Admin will only appear in the same browser/device. The demo password is NOT secure and must not be used on a public website.

To make the real free online version:
- Connect Supabase (free tier) for secure admin sign-in, product database, and image storage.
- Replace demo login/localStorage with Supabase Auth + database + storage.
- Deploy the static website on a free hosting plan.
- Keep the Supabase secret/service-role key private; never put it in browser code.
- Have a parent/guardian help with account setup if required by the service's age rules.

Reference images supplied by the user are included in assets/.
