const defaults=[
{name:"Poedagar Watch",price:2850,category:"Watch",badge:"New",img:"assets/watch.jpg"},
{name:"HOPE Perfume",price:1200,category:"Perfume",badge:"Premium",img:"assets/perfume.jpg"},
{name:"Die-Cast Car (1:43)",price:1450,category:"Die-cast",badge:"Hot",img:"assets/car.jpg"},
{name:"Sport Watch",price:2650,category:"Watch",badge:"Best Seller",img:"assets/sport-watch.jpg"}];
function getProducts(){try{return JSON.parse(localStorage.getItem("hopeProducts"))||defaults}catch(e){return defaults}}
function render(){let q=(document.getElementById("search")?.value||"").toLowerCase();let p=getProducts().filter(x=>x.name.toLowerCase().includes(q)||x.category.toLowerCase().includes(q));document.getElementById("products").innerHTML=p.map((x,i)=>`<article class="product"><span class="tag">${x.badge||"HOPE"}</span><img src="${x.img}" alt=""><h3>${x.name}</h3><div class="price">৳ ${Number(x.price).toLocaleString("en-BD")}</div><button onclick="addCart()">🛒 Add to Cart</button></article>`).join("")}
let cart=0;function addCart(){cart++;document.getElementById("cartCount").textContent=cart}
document.getElementById("search").addEventListener("input",render);document.getElementById("top").onclick=()=>window.scrollTo({top:0,behavior:"smooth"});
const intro=document.getElementById("intro");if(sessionStorage.getItem("hopeIntroSeen"))intro.classList.add("hide");document.getElementById("skipIntro").onclick=()=>{intro.classList.add("hide");sessionStorage.setItem("hopeIntroSeen","1")};setTimeout(()=>{intro.classList.add("hide");sessionStorage.setItem("hopeIntroSeen","1")},4500);render();